import json
import boto3
import time
from datetime import datetime, timezone

# ── Config ────────────────────────────────────────────────────────────────────
ATHENA_DATABASE   = "finops_analytics"
ATHENA_TABLE      = "cur_daily_cost_governance_report"
ATHENA_OUTPUT     = "s3://aws-finops-athena-results-prod/"
DASHBOARD_BUCKET  = "aws-finops-dashboard-output-prod"
DASHBOARD_KEY     = "index.html"
AWS_REGION        = "us-east-1"

athena = boto3.client("athena", region_name=AWS_REGION)
s3     = boto3.client("s3",     region_name=AWS_REGION)


# ── Athena helpers ─────────────────────────────────────────────────────────────
def run_query(sql):
    resp = athena.start_query_execution(
        QueryString=sql,
        QueryExecutionContext={"Database": ATHENA_DATABASE},
        ResultConfiguration={"OutputLocation": ATHENA_OUTPUT},
        WorkGroup="primary"
    )
    qid = resp["QueryExecutionId"]
    for _ in range(60):
        state = athena.get_query_execution(QueryExecutionId=qid)[
            "QueryExecution"]["Status"]["State"]
        if state == "SUCCEEDED":
            break
        if state in ("FAILED", "CANCELLED"):
            raise RuntimeError(f"Athena query {state}: {sql[:120]}")
        time.sleep(2)
    rows = []
    paginator = athena.get_paginator("get_query_results")
    first = True
    for page in paginator.paginate(QueryExecutionId=qid):
        for row in page["ResultSet"]["Rows"]:
            if first:
                first = False
                continue
            rows.append([c.get("VarCharValue", "") for c in row["Data"]])
    return rows


def safe_float(val, default=0.0):
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


# ── Data fetchers ──────────────────────────────────────────────────────────────
def fetch_mtd_spend():
    sql = f"""
        SELECT
            line_item_product_code,
            ROUND(SUM(line_item_unblended_cost), 2) AS cost
        FROM {ATHENA_TABLE}
        WHERE year = '2026' AND month = '11'
          AND line_item_line_item_type NOT IN ('Credit', 'Refund')
        GROUP BY line_item_product_code
        ORDER BY cost DESC
        LIMIT 15
    """
    rows = run_query(sql)
    services, costs = [], []
    total = 0.0
    for r in rows:
        svc  = r[0] if r[0] else "Other"
        cost = safe_float(r[1])
        services.append(svc)
        costs.append(cost)
        total += cost
    return round(total, 2), services, costs


def fetch_daily_trend():
    sql = f"""
        SELECT
            line_item_usage_start_date,
            ROUND(SUM(line_item_unblended_cost), 2) AS daily_cost
        FROM {ATHENA_TABLE}
        WHERE year = '2026' AND month = '11'
          AND line_item_line_item_type NOT IN ('Credit', 'Refund')
        GROUP BY line_item_usage_start_date
        ORDER BY line_item_usage_start_date
    """
    rows = run_query(sql)
    labels, values = [], []
    for r in rows:
        raw = r[0][:10] if r[0] else ""
        labels.append(raw)
        values.append(safe_float(r[1]))
    return labels, values


def fetch_tagging_compliance():
    return 0.0



# ── Simulated governance data ─────────────────────────────────────────────────
GOVERNANCE_ROWS = [
    {"id": "i-0f2a4b6c8d1e3f5a", "account": "123456789012", "env": "Prod",
     "service": "EC2", "issue": "Over-provisioned CPU (<5% avg)",
     "impact": 47.20, "action": "Downsize"},
    {"id": "vol-0a1b2c3d4e5f6a7b", "account": "123456789012", "env": "Prod",
     "service": "EBS", "issue": "Unattached volume (14 days)",
     "impact": 12.80, "action": "Delete Volume"},
    {"id": "i-0c3d5e7f9a1b2c4d", "account": "234567890123", "env": "Dev",
     "service": "EC2", "issue": "Missing cost-allocation tags",
     "impact": 31.50, "action": "Enforce Tag"},
    {"id": "rds-0d4e6f8a0b2c3d5e", "account": "234567890123", "env": "Dev",
     "service": "RDS", "issue": "No automated backup lifecycle policy",
     "impact": 18.90, "action": "Set Lifecycle"},
    {"id": "i-0e5f7a9b1c3d4e6f", "account": "345678901234", "env": "Staging",
     "service": "EC2", "issue": "Over-provisioned CPU (<3% avg)",
     "impact": 55.60, "action": "Downsize"},
    {"id": "vol-0b2c4d6e8f0a1b3c", "account": "345678901234", "env": "Staging",
     "service": "EBS", "issue": "Unattached volume (30 days)",
     "impact": 9.40,  "action": "Delete Volume"},
    {"id": "lambda-0f1a2b3c4d5e6f7a", "account": "123456789012", "env": "Prod",
     "service": "Lambda", "issue": "Missing cost-allocation tags",
     "impact": 6.20,  "action": "Enforce Tag"},
    {"id": "i-0a1b3c5d7e9f0a2b", "account": "234567890123", "env": "Dev",
     "service": "EC2", "issue": "Idle instance (<1% CPU, 7 days)",
     "impact": 22.10, "action": "Stop / Terminate"},
]


# ── HTML builder ───────────────────────────────────────────────────────────────
def build_html(mtd, services, costs, labels, values, tag_pct, gov_rows, sync_ts):
    import json
    days_elapsed   = int(sync_ts[8:10])
    projected      = round((mtd / max(days_elapsed, 1)) * 30, 2) if days_elapsed else 0
    budget_limit   = 500.00
    savings        = round(sum(r["impact"] for r in gov_rows), 2)
    items_count    = len(gov_rows)
    mtd_str        = "${:,.2f}".format(mtd)
    projected_str  = "${:,.2f}".format(projected)
    savings_str    = "${:,.2f}".format(savings)
    budget_str     = "${:,.2f}".format(budget_limit)
    budget_pct     = round((projected / budget_limit) * 100, 1)
    budget_pct_str = "{}%".format(budget_pct)
    tag_pct_str    = "{}%".format(tag_pct)
    tag_health     = "&#10003; Healthy" if tag_pct >= 80 else "&#9888; Needs Attention"
    tag_class      = "down" if tag_pct >= 80 else "up"
    mom_variance   = "+12.4%"
    trend_labels_js = json.dumps(labels)
    trend_values_js = json.dumps(values)
    svc_labels_js   = json.dumps(services)
    svc_costs_js    = json.dumps(costs)
    gov_json        = json.dumps(gov_rows)



    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>AWS FinOps Cost Governance Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  :root {{
    --bg:#0f172a;--surface:#1e293b;--surface2:#334155;
    --accent:#6366f1;--accent2:#8b5cf6;--green:#10b981;
    --yellow:#f59e0b;--red:#ef4444;--text:#f1f5f9;--muted:#94a3b8;
  }}
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{background:var(--bg);color:var(--text);font-family:'Inter',system-ui,sans-serif;min-height:100vh}}
  .header{{background:linear-gradient(135deg,#1e293b,#0f172a);border-bottom:1px solid #334155;
           padding:18px 32px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px}}
  .header-left h1{{font-size:1.35rem;font-weight:700;background:linear-gradient(90deg,#6366f1,#8b5cf6);
                   -webkit-background-clip:text;-webkit-text-fill-color:transparent}}
  .header-left p{{font-size:.78rem;color:var(--muted);margin-top:3px}}
  .badges{{display:flex;gap:10px;flex-wrap:wrap}}
  .badge{{padding:5px 12px;border-radius:20px;font-size:.72rem;font-weight:600;display:flex;align-items:center;gap:5px}}
  .badge-blue{{background:rgba(99,102,241,.15);border:1px solid rgba(99,102,241,.4);color:#a5b4fc}}
  .badge-green{{background:rgba(16,185,129,.15);border:1px solid rgba(16,185,129,.4);color:#6ee7b7}}
  .badge-yellow{{background:rgba(245,158,11,.15);border:1px solid rgba(245,158,11,.4);color:#fcd34d}}
  .kpi-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;padding:24px 32px}}
  .kpi{{background:var(--surface);border:1px solid #334155;border-radius:12px;padding:20px;position:relative;overflow:hidden}}
  .kpi::before{{content:'';position:absolute;top:0;left:0;right:0;height:3px}}
  .kpi-blue::before{{background:linear-gradient(90deg,#6366f1,#8b5cf6)}}
  .kpi-green::before{{background:linear-gradient(90deg,#10b981,#34d399)}}
  .kpi-yellow::before{{background:linear-gradient(90deg,#f59e0b,#fbbf24)}}
  .kpi-red::before{{background:linear-gradient(90deg,#ef4444,#f87171)}}
  .kpi-label{{font-size:.72rem;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px}}
  .kpi-value{{font-size:1.9rem;font-weight:700}}
  .kpi-sub{{font-size:.75rem;color:var(--muted);margin-top:6px}}
  .kpi-badge{{display:inline-block;padding:2px 8px;border-radius:10px;font-size:.7rem;font-weight:600;margin-top:6px}}
  .up{{background:rgba(239,68,68,.15);color:#f87171}}
  .down{{background:rgba(16,185,129,.15);color:#6ee7b7}}
  .charts-grid{{display:grid;grid-template-columns:2fr 1fr;gap:16px;padding:0 32px 24px}}
  @media(max-width:900px){{.charts-grid{{grid-template-columns:1fr}}}}
  .chart-card{{background:var(--surface);border:1px solid #334155;border-radius:12px;padding:20px}}
  .chart-title{{font-size:.85rem;font-weight:600;color:var(--muted);margin-bottom:16px;text-transform:uppercase;letter-spacing:.05em}}
  .chart-wrap{{position:relative;height:240px}}
  .doughnut-wrap{{position:relative;height:240px;display:flex;align-items:center;justify-content:center}}
  .doughnut-center{{position:absolute;top:50%;left:35%;transform:translate(-50%,-50%);text-align:center;pointer-events:none}}
  .doughnut-center span{{display:block;font-size:.7rem;color:var(--muted)}}
  .doughnut-center strong{{display:block;font-size:1.2rem;font-weight:700}}
  .table-section{{padding:0 32px 32px}}
  .table-header{{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:16px}}
  .table-header h2{{font-size:1rem;font-weight:600}}
  .controls{{display:flex;gap:10px;flex-wrap:wrap}}
  .search-box{{background:var(--surface);border:1px solid #334155;border-radius:8px;
               padding:8px 14px;color:var(--text);font-size:.82rem;width:220px;outline:none}}
  .search-box:focus{{border-color:var(--accent)}}
  .select-box{{background:var(--surface);border:1px solid #334155;border-radius:8px;
               padding:8px 14px;color:var(--text);font-size:.82rem;outline:none;cursor:pointer}}
  .export-btn{{background:linear-gradient(135deg,#6366f1,#8b5cf6);border:none;border-radius:8px;
               padding:8px 16px;color:#fff;font-size:.82rem;font-weight:600;cursor:pointer}}
  .export-btn:hover{{opacity:.9}}
  table{{width:100%;border-collapse:collapse;background:var(--surface);border-radius:12px;overflow:hidden;border:1px solid #334155}}
  thead tr{{background:#1a2744}}
  th{{padding:12px 16px;text-align:left;font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;
      color:var(--muted);cursor:pointer;user-select:none;white-space:nowrap}}
  th:hover{{color:var(--text)}}
  td{{padding:12px 16px;font-size:.82rem;border-top:1px solid #1e293b}}
  tr:hover td{{background:rgba(99,102,241,.05)}}
  .tag{{padding:3px 10px;border-radius:12px;font-size:.7rem;font-weight:600}}
  .tag-down{{background:rgba(99,102,241,.2);color:#a5b4fc}}
  .tag-delete{{background:rgba(239,68,68,.2);color:#f87171}}
  .tag-tag{{background:rgba(245,158,11,.2);color:#fcd34d}}
  .tag-lifecycle{{background:rgba(16,185,129,.2);color:#6ee7b7}}
  .tag-stop{{background:rgba(239,68,68,.2);color:#f87171}}
  .impact-cell{{font-weight:600;color:#f87171}}
  .footer{{text-align:center;padding:20px;font-size:.72rem;color:var(--muted);border-top:1px solid #1e293b}}
</style>
</head>
<body>
<div class="header">
  <div class="header-left">
    <h1>&#9650; AWS FinOps Cost Governance Dashboard</h1>
    <p>Last sync: {sync_ts} UTC &nbsp;|&nbsp; Data source: AWS Cost &amp; Usage Report (Athena)</p>
  </div>
  <div class="badges">
    <span class="badge badge-blue">&#128203; 3 Accounts Tracked</span>
    <span class="badge badge-green">&#128274; CloudFront + OAC Protected</span>
    <span class="badge badge-yellow">&#9889; Live Aggregation Active</span>
  </div>
</div>
<div class="kpi-grid">
  <div class="kpi kpi-blue">
    <div class="kpi-label">MTD Spend</div>
    <div class="kpi-value">{mtd_str}</div>
    <div class="kpi-sub">Month-to-date across all accounts</div>
    <span class="kpi-badge up">&#8593; {mom_variance} MoM</span>
  </div>
  <div class="kpi kpi-yellow">
    <div class="kpi-label">Projected EOM Run-Rate</div>
    <div class="kpi-value">{projected_str}</div>
    <div class="kpi-sub">Budget limit: {budget_str}</div>
    <span class="kpi-badge" style="background:rgba(245,158,11,.15);color:#fcd34d">{budget_pct_str} of budget</span>
  </div>
  <div class="kpi kpi-green">
    <div class="kpi-label">Tagging Compliance</div>
    <div class="kpi-value">{tag_pct_str}</div>
    <div class="kpi-sub">Resources with cost-allocation tags</div>
    <span class="kpi-badge {tag_class}">{tag_health}</span>
  </div>
  <div class="kpi kpi-red">
    <div class="kpi-label">Identified Savings</div>
    <div class="kpi-value">{savings_str}<span style="font-size:1rem">/mo</span></div>
    <div class="kpi-sub">{len(gov_rows)} rightsizing &amp; idle items flagged</div>
    <span class="kpi-badge up">&#9650; Action Required</span>
  </div>
</div>
<div class="charts-grid">
  <div class="chart-card">
    <div class="chart-title">Daily Cost Trend — November 2026</div>
    <div class="chart-wrap"><canvas id="trendChart"></canvas></div>
  </div>
  <div class="chart-card">
    <div class="chart-title">Cost Distribution by Service</div>
    <div class="doughnut-wrap">
      <canvas id="doughnutChart"></canvas>
      <div class="doughnut-center">
        <span>Total</span>
        <strong>{mtd_str}</strong>
      </div>
    </div>
  </div>
</div>
<div class="table-section">
  <div class="table-header">
    <h2>Actionable Governance &amp; Rightsizing</h2>
    <div class="controls">
      <input class="search-box" id="searchInput" type="text" placeholder="&#128269; Search resources, issues..."/>
      <select class="select-box" id="envFilter">
        <option value="">All Environments</option>
        <option value="Prod">Prod</option>
        <option value="Dev">Dev</option>
        <option value="Staging">Staging</option>
      </select>
      <button class="export-btn" onclick="exportCSV()">&#8595; Export CSV</button>
    </div>
  </div>
  <table id="govTable">
    <thead>
      <tr>
        <th onclick="sortTable(0)">Resource ID &#8597;</th>
        <th onclick="sortTable(1)">Account ID &#8597;</th>
        <th onclick="sortTable(2)">Env &#8597;</th>
        <th onclick="sortTable(3)">Service &#8597;</th>
        <th onclick="sortTable(4)">Issue &#8597;</th>
        <th onclick="sortTable(5)">Monthly Impact &#8597;</th>
        <th onclick="sortTable(6)">Action &#8597;</th>
      </tr>
    </thead>
    <tbody id="govBody"></tbody>
  </table>
</div>
<div class="footer">AWS FinOps Cost Governance Dashboard &nbsp;|&nbsp; Generated by Lambda &nbsp;|&nbsp; {sync_ts} UTC</div>
<script>
Chart.defaults.color="#94a3b8";Chart.defaults.borderColor="#1e293b";
const trendCtx=document.getElementById("trendChart").getContext("2d");
const trendGrad=trendCtx.createLinearGradient(0,0,0,240);
trendGrad.addColorStop(0,"rgba(99,102,241,0.35)");trendGrad.addColorStop(1,"rgba(99,102,241,0.02)");
new Chart(trendCtx,{{type:"line",data:{{labels:{trend_labels_js},datasets:[{{label:"Daily Spend ($)",
data:{trend_values_js},borderColor:"#6366f1",backgroundColor:trendGrad,borderWidth:2,
pointRadius:3,pointBackgroundColor:"#6366f1",fill:true,tension:0.4}}]}},
options:{{responsive:true,maintainAspectRatio:false,
plugins:{{legend:{{display:false}},tooltip:{{callbacks:{{label:ctx=>"$"+ctx.parsed.y.toFixed(2)}}}}}},
scales:{{x:{{grid:{{color:"#1e293b"}},ticks:{{maxTicksLimit:8}}}},
y:{{grid:{{color:"#1e293b"}},ticks:{{callback:v=>"$"+v.toFixed(0)}}}}}}
}}}});
const palette=["#6366f1","#8b5cf6","#ec4899","#f59e0b","#10b981","#06b6d4","#f87171","#34d399","#fbbf24","#a78bfa"];
new Chart(document.getElementById("doughnutChart").getContext("2d"),{{type:"doughnut",
data:{{labels:{svc_labels_js},datasets:[{{data:{svc_costs_js},backgroundColor:palette,
borderColor:"#1e293b",borderWidth:2,hoverOffset:6}}]}},
options:{{responsive:true,maintainAspectRatio:false,cutout:"72%",
plugins:{{legend:{{position:"right",labels:{{boxWidth:10,padding:10,font:{{size:11}}}}}},
tooltip:{{callbacks:{{label:ctx=>ctx.label+": $"+ctx.parsed.toFixed(2)}}}}}}
}}}});
const govData={gov_json};
const actionClass={{"Downsize":"tag-down","Delete Volume":"tag-delete","Enforce Tag":"tag-tag","Set Lifecycle":"tag-lifecycle","Stop / Terminate":"tag-stop"}};
function renderTable(data){{
  const tbody=document.getElementById("govBody");tbody.innerHTML="";
  data.forEach(r=>{{
    const cls=actionClass[r.action]||"tag-down";
    tbody.innerHTML+=`<tr><td style="font-family:monospace;font-size:.78rem">${{r.id}}</td>
    <td>${{r.account}}</td><td>${{r.env}}</td><td>${{r.service}}</td><td>${{r.issue}}</td>
    <td class="impact-cell">$${{r.impact.toFixed(2)}}</td>
    <td><span class="tag ${{cls}}">${{r.action}}</span></td></tr>`;
  }});
}}
renderTable(govData);
function filterTable(){{
  const q=document.getElementById("searchInput").value.toLowerCase();
  const env=document.getElementById("envFilter").value;
  renderTable(govData.filter(r=>(!env||r.env===env)&&(!q||[r.id,r.account,r.service,r.issue,r.action].some(v=>v.toLowerCase().includes(q)))));
}}
document.getElementById("searchInput").addEventListener("input",filterTable);
document.getElementById("envFilter").addEventListener("change",filterTable);
let sortDir={{}};
function sortTable(col){{
  const keys=["id","account","env","service","issue","impact","action"];
  const k=keys[col];sortDir[k]=!sortDir[k];
  const q=document.getElementById("searchInput").value.toLowerCase();
  const env=document.getElementById("envFilter").value;
  const filtered=govData.filter(r=>(!env||r.env===env)&&(!q||[r.id,r.account,r.service,r.issue,r.action].some(v=>v.toLowerCase().includes(q))));
  filtered.sort((a,b)=>{{const av=a[k],bv=b[k];if(typeof av==="number")return sortDir[k]?av-bv:bv-av;return sortDir[k]?String(av).localeCompare(String(bv)):String(bv).localeCompare(String(av));}});
  renderTable(filtered);
}}
function exportCSV(){{
  const headers=["Resource ID","Account ID","Environment","Service","Issue","Monthly Impact ($)","Action"];
  const rows = govData.map(r => [r.id, r.account, r.env, r.service, `"${{r.issue}}"`, r.impact.toFixed(2), `"${{r.action}}"`]);
  const csv=[headers.join(","),...rows.map(r=>r.join(","))].join("\\n");
  const a=document.createElement("a");a.href="data:text/csv;charset=utf-8,"+encodeURIComponent(csv);
  a.download="aws_finops_governance_report.csv";a.click();
}}
</script>
</body>
</html>"""


# ── Lambda handler ─────────────────────────────────────────────────────────────
def lambda_handler(event, context):
    try:
        sync_ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        print(f"[INFO] Starting FinOps dashboard generation at {sync_ts}")

        mtd, services, costs = fetch_mtd_spend()
        print(f"[INFO] MTD spend: ${mtd}")

        labels, values = fetch_daily_trend()
        print(f"[INFO] Daily trend: {len(labels)} data points")

        tag_pct = fetch_tagging_compliance()
        print(f"[INFO] Tagging compliance: {tag_pct}%")

        html = build_html(mtd, services, costs, labels, values,
                          tag_pct, GOVERNANCE_ROWS, sync_ts)

        s3.put_object(
            Bucket=DASHBOARD_BUCKET,
            Key=DASHBOARD_KEY,
            Body=html.encode("utf-8"),
            ContentType="text/html",
            CacheControl="no-cache, no-store, must-revalidate",
        )
        print(f"[INFO] Dashboard uploaded to s3://{DASHBOARD_BUCKET}/{DASHBOARD_KEY}")

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Dashboard generated successfully",
                "mtd_spend": mtd,
                "sync_timestamp": sync_ts,
                "s3_path": f"s3://{DASHBOARD_BUCKET}/{DASHBOARD_KEY}"
            })
        }

    except Exception as e:
        print(f"[ERROR] {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
